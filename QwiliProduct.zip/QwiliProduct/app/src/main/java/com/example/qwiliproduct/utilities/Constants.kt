package com.example.qwiliproduct.utilities

object Constants {
    val BASE_URL = "https://dummyjson.com/"
}